package snake;

import javax.swing.JFrame;

@SuppressWarnings("serial")
public class GameFrame extends JFrame
{
	GameFrame()
		{
		
			this.add(new GamePanel());
			this.setTitle("Yashu's Ophidian Game");
			this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			this.setResizable(false);
			this.pack();//takes the jframe n spilts to other components
			this.setVisible(true);
			this.setLocationRelativeTo(null);//to cet screen to center of computer
			
			
			
		}

		



}
